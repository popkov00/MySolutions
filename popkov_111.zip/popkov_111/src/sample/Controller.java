package sample;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class Controller {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField textX;

    @FXML
    private TextField textA;

    @FXML
    private TextField textB;

    @FXML
    private Button btnClear;

    @FXML
    private Button btnExit;

    @FXML
    private Button btnSolve;

    @FXML
    private TextField textOtvet;

    @FXML
    void initialize() {
        //assert textX != null : "fx:id=\"textX\" was not injected: check your FXML file 'sample.fxml'.";
        //assert textA != null : "fx:id=\"textA\" was not injected: check your FXML file 'sample.fxml'.";
        //assert textB != null : "fx:id=\"textB\" was not injected: check your FXML file 'sample.fxml'.";
        //assert btnClear != null : "fx:id=\"btnClear\" was not injected: check your FXML file 'sample.fxml'.";
        //assert btnExit != null : "fx:id=\"btnExit\" was not injected: check your FXML file 'sample.fxml'.";
        //assert btnSolve != null : "fx:id=\"btnSolve\" was not injected: check your FXML file 'sample.fxml'.";
      btnExit.setOnAction(event->{ System.exit(0); });
      btnClear.setOnAction(event->{textA.setText("");
                                     textB.setText("");
                                     textX.setText("");});
      btnSolve.setOnAction(event->{
          double A = Double. parseDouble(textA.getText());
          double B = Double. parseDouble(textB.getText());
          double X = Double. parseDouble(textX.getText());
          double Y;
          if(X<=7)
          { Y = (X+4)/(Math.pow(A,2)+Math.pow(B,2));}
          else
          { Y = X*Math.pow(A+B,2);}
          textOtvet.setText(Double.toString(Y));

      });

    }
}