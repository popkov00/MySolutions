package sample;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class Controller {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField textX;

    @FXML
    private TextField textX1;

    @FXML
    private TextField textA;

    @FXML
    private TextField textB;

    @FXML
    private Button btnClear;

    @FXML
    private Button btnExit;

    @FXML
    private Button btnSolve;

    @FXML
    private Button btnSolve1;

    @FXML
    void initialize() {

        btnExit.setOnAction(event->{ System.exit(0); });
        btnClear.setOnAction(event->{textA.setText("");
            textB.setText(""); });

        btnSolve.setOnAction(event->{
            int s=0;
            double A = Double. parseDouble(textA.getText());
            double B = Double. parseDouble(textB.getText());
            // создаем пустой массив из 10 элементов
            double array[] = new double[10];
            // создаем пустой массив из 9 элементов
            double array1[] = new double[9];
            //рассчитывем Y[i]
            for (int j=0; j < 9; j++) {
                for (int i=1; i <= 9; i++) {
                    s += array[i] + array[i-1];
                    if (array[i] == 0 & A == 0 & B == 0) {System.out.println("Пример не имеет решения"); break;}
                    else if (A == 0 & B == 0) {System.out.println("Пример не имеет решения"); break; }
                    else {
                        array1[j] = Math.sqrt(Math.pow(Math.cos(array[i]),2)/(Math.pow(A,2) + Math.pow(B,2) - Math.sin(array[i]))) * s;
                        textX.setText(Double.toString(array1[j] ));
                    }
                }
            }

        });

        btnSolve1.setOnAction(event->{
            // создаем пустой массив из 10 элементов
            double array[] = new double[10];
            //заполняем массив array случайными числами от 0 до 99
            Random rand = new Random();
            for (int i=0; i < 10; i++) {
                array[i] = rand.nextInt(100);
                textX1.setText(Double.toString(array[i]));
            }
        });

    }
}